﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrolmentsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EnrolmentsController(AppDbContext context)
        {
            _context = context;
        }

        // POST: api/Enrolments
        [HttpPost]
        public async Task<IActionResult> EnrolInEvent([FromBody] EnrolmentDto request)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role != "Participant" || userId == null) return Forbid("Only Participants can enrol in events.");

            // Check if already enrolled
            var existing = await _context.Enrolments
                .FirstOrDefaultAsync(e => e.UserId == userId && e.EventId == request.EventId);

            if (existing != null) return BadRequest("You are already enrolled in this event.");

            var enrolment = new Enrolment
            {
                UserId = userId.Value,
                EventId = request.EventId,
                CategoryId = request.CategoryId
            };

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Successfully enrolled!", enrolmentId = enrolment.Id });
        }

        // GET: api/Enrolments/event/5
        [HttpGet("event/{eventId}")]
        public async Task<IActionResult> GetEnrolmentsForEvent(int eventId)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role != "Organiser" || userId == null) return Forbid("Only Organisers can view all enrolments.");

            // Ensure organiser owns the event
            var eventItem = await _context.Events.FindAsync(eventId);
            if (eventItem == null || eventItem.OrganiserId != userId) return Forbid("You can only view enrolments for your own events.");

            var enrolments = await _context.Enrolments
                .Include(e => e.User)
                .Include(e => e.Category)
                .Where(e => e.EventId == eventId)
                .Select(e => new
                {
                    e.Id,
                    ParticipantName = $"{e.User.FirstName} {e.User.LastName}",
                    Category = e.Category.Name,
                    e.FinishTime,
                    e.FinishingPosition
                })
                .ToListAsync();

            return Ok(enrolments);
        }

        // GET: api/Enrolments/my-results
        [HttpGet("my-results")]
        public async Task<IActionResult> GetMyResults()
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role != "Participant" || userId == null) return Forbid("Only Participants can view their results.");

            var results = await _context.Enrolments
                .Include(e => e.Event)
                .Where(e => e.UserId == userId)
                .Select(e => new
                {
                    EventName = e.Event.Name,
                    e.FinishTime,
                    e.FinishingPosition
                })
                .ToListAsync();

            return Ok(results);
        }

        // PUT: api/Enrolments/5/result
        [HttpPut("{id}/result")]
        public async Task<IActionResult> UpdateResult(int id, [FromBody] ResultDto request)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role != "Organiser" || userId == null) return Forbid("Only Organisers can capture results.");

            var enrolment = await _context.Enrolments
                .Include(e => e.Event)
                .FirstOrDefaultAsync(e => e.Id == id);

            if (enrolment == null) return NotFound("Enrolment not found.");
            if (enrolment.Event.OrganiserId != userId) return Forbid("You can only capture results for your own events.");

            enrolment.FinishTime = request.FinishTime;
            enrolment.FinishingPosition = request.FinishingPosition;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Result recorded successfully." });
        }
    }

    public class EnrolmentDto
    {
        public int EventId { get; set; }
        public int CategoryId { get; set; }
    }

    public class ResultDto
    {
        public TimeSpan? FinishTime { get; set; }
        public int? FinishingPosition { get; set; }
    }
}