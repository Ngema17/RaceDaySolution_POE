﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;
using RaceDay.API.Services;
using RaceDay.API.DTOs; // Must be here to see the DTO

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly BlobService _blobService;
        private AppDbContext context;

        public EventsController(AppDbContext context, BlobService blobService)
        {
            _context = context;
            _blobService = blobService;
        }

        public EventsController(AppDbContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllEvents()
        {
            var events = await _context.Events.ToListAsync();
            return Ok(events);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEvent([FromForm] CreateEventDto dto)
        {
            // 1. Authentication check
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role == null || userId == null) return Unauthorized("Please log in.");
            if (role != "Organiser") return Forbid("Only Organisers can create events.");

            // 2. Upload Image
            string imageUrl = null;
            if (dto.BannerImage != null)
            {
                imageUrl = await _blobService.UploadFileAsync(dto.BannerImage);
            }

            // 3. Save Event
            var newEvent = new Event
            {
                Name = dto.Name,
                Description = dto.Description,
                Date = dto.Date,
                Location = dto.Location,
                Distance = dto.Distance,
                EventType = dto.EventType,
                OrganiserId = userId.Value,
                BannerImageUrl = imageUrl
            };

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Event created successfully!", eventId = newEvent.Id });
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] Event updatedEvent)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role != "Organiser" || userId == null) return Forbid("Only Organisers can update events.");

            var existingEvent = await _context.Events.FindAsync(id);
            if (existingEvent == null) return NotFound("Event not found.");
            if (existingEvent.OrganiserId != userId) return Forbid("You can only update your own events.");

            existingEvent.Name = updatedEvent.Name;
            existingEvent.Description = updatedEvent.Description;
            existingEvent.Date = updatedEvent.Date;
            existingEvent.Location = updatedEvent.Location;
            existingEvent.Distance = updatedEvent.Distance;
            existingEvent.EventType = updatedEvent.EventType;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Event updated successfully." });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role != "Organiser" || userId == null) return Forbid("Only Organisers can delete events.");

            var eventToDelete = await _context.Events.FindAsync(id);
            if (eventToDelete == null) return NotFound("Event not found.");
            if (eventToDelete.OrganiserId != userId) return Forbid("You can only delete your own events.");

            _context.Events.Remove(eventToDelete);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Event deleted successfully." });
        }

        public async Task CreateEvent(Event newEvent)
        {
            throw new NotImplementedException();
        }
    }
}