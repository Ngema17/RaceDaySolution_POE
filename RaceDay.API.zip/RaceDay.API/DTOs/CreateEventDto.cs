﻿using System;
using Microsoft.AspNetCore.Http; // Required for IFormFile

namespace RaceDay.API.DTOs
{
    public class CreateEventDto
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public string Location { get; set; } = string.Empty;
        public double Distance { get; set; }
        public string EventType { get; set; } = string.Empty;
        
        public IFormFile? BannerImage { get; set; } 
    }
}