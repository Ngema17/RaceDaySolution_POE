﻿namespace RaceDay.API.Models
{
    public class Enrolment
    {
        public int Id { get; set; }

        public int UserId { get; set; } // The Participant
        public User User { get; set; } = null!;

        public int EventId { get; set; }
        public Event Event { get; set; } = null!;

        public int CategoryId { get; set; }
        public Category Category { get; set; } = null!;

        // Result properties (Organisers will update these later)
        public TimeSpan? FinishTime { get; set; }
        public int? FinishingPosition { get; set; }
    }
}