﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using RaceDay.MVC.Services;
using System.Text.Json;
using System.Net.Http.Headers;

namespace RaceDay.MVC.Controllers
{
    public class OrganiserController : Controller
    {
        private readonly ApiService _apiService;

        public OrganiserController(ApiService apiService)
        {
            _apiService = apiService;
        }

        // Security check: Only allow Organisers to access this controller
        private bool IsOrganiser()
        {
            return HttpContext.Session.GetString("UserRole") == "Organiser";
        }

        // ==========================================
        // 1. DASHBOARD
        // ==========================================
        public async Task<IActionResult> Dashboard()
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Account");

            // Fetch events from API to calculate stats
            var events = await _apiService.GetAsync<List<EventDto>>("api/Events");
            var myEvents = events?.Where(e => e.OrganiserId == HttpContext.Session.GetInt32("UserId")).ToList() ?? new List<EventDto>();

            ViewBag.TotalEvents = myEvents.Count;
            ViewBag.UpcomingEvents = myEvents.Count(e => e.Date > DateTime.Now);

            // Note: To get total enrolments, you would need an API endpoint that returns all enrolments. 
            // For now, we'll pass 0 as a placeholder if you don't have that endpoint yet.
            ViewBag.TotalEnrolments = 0;

            return View(myEvents);
        }

        // ==========================================
        // 2. CREATE EVENT
        // ==========================================
        [HttpGet]
        public IActionResult CreateEvent()
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateEvent(EventDto model, IFormFile BannerImage)
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                var formData = new MultipartFormDataContent();
                formData.Add(new StringContent(model.Name), "Name");
                formData.Add(new StringContent(model.Description ?? ""), "Description");
                formData.Add(new StringContent(model.Date.ToString("o")), "Date");
                formData.Add(new StringContent(model.Location ?? ""), "Location");
                formData.Add(new StringContent(model.Distance.ToString()), "Distance");
                formData.Add(new StringContent(model.EventType ?? ""), "EventType");

                if (BannerImage != null && BannerImage.Length > 0)
                {
                    var fileContent = new StreamContent(BannerImage.OpenReadStream());
                    fileContent.Headers.ContentType = new MediaTypeHeaderValue(BannerImage.ContentType);
                    formData.Add(fileContent, "BannerImage", BannerImage.FileName);
                }

                var response = await _apiService.PostFormAsync("api/Events", formData);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Dashboard");
                }
                ModelState.AddModelError("", "Failed to create event. Please try again.");
            }
            return View(model);
        }

        // ==========================================
        // 3. EDIT EVENT (GET)
        // ==========================================
        [HttpGet]
        public async Task<IActionResult> EditEvent(int id)
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Account");

            var events = await _apiService.GetAsync<List<EventDto>>("api/Events");
            var eventToEdit = events?.FirstOrDefault(e => e.Id == id && e.OrganiserId == HttpContext.Session.GetInt32("UserId"));

            if (eventToEdit == null) return NotFound("Event not found or you don't have permission.");

            return View(eventToEdit);
        }

        // ==========================================
        // 4. EDIT EVENT (POST)
        // ==========================================
        [HttpPost]
        public async Task<IActionResult> EditEvent(int id, EventDto model)
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                // Note: Since we're not uploading an image here, we just send JSON.
                // If you want to update the image, you'd use the same formData approach as CreateEvent.
                var response = await _apiService.PostAsync($"api/Events/{id}", model);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Dashboard");
                }
                ModelState.AddModelError("", "Failed to update event. Please try again.");
            }
            return View(model);
        }

        // ==========================================
        // 5. DELETE EVENT
        // ==========================================
        [HttpPost]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Account");

            var response = await _apiService.PostAsync($"api/Events/{id}", null);
            // Note: You'll need to adjust your ApiService to support HttpDelete or create a specific method for it.
            // For now, this assumes your API's DeleteEvent endpoint works with a POST or GET.

            return RedirectToAction("Dashboard");
        }

        // ==========================================
        // 6. MANAGE RESULTS
        // ==========================================
        [HttpGet]
        public async Task<IActionResult> Results(int id)
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Account");

            // We need to fetch the event details and the enrolments.
            // Since we don't have a specific endpoint for enrolments yet, we'll show the UI first.
            ViewBag.EventId = id;
            return View();
        }
    }

    // Helper class to match the API's Event model
    public class EventDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public string Location { get; set; } = string.Empty;
        public double Distance { get; set; }
        public string EventType { get; set; } = string.Empty;
        public int OrganiserId { get; set; }
        public string? BannerImageUrl { get; set; }
    }
}