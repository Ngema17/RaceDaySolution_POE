﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Controllers;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
using RaceDay.API.Services;
using Microsoft.Extensions.Configuration;

// This alias fixes the naming collision
using AppDbContext = RaceDay.API.Data.AppDbContext;

namespace RaceDay.Tests
{
    public class AuthAndRoleTests : AuthAndRoleTestsBase
    {
        private AppDbContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            return new AppDbContext(options);
        }

        // Helper to mock HttpContext.Session
        private void SetupSession(ControllerBase controller, int? userId, string role)
        {
            var mockSession = new Mock<ISession>();

            // Mocking extension methods directly can be tricky in Moq, so we mock the underlying TryGetValue if needed, 
            // but for simplicity, let's assume your session mock setup works as written.
            byte[] userIdBytes = userId.HasValue ? BitConverter.GetBytes(userId.Value) : null;
            byte[] roleBytes = role != null ? System.Text.Encoding.UTF8.GetBytes(role) : null;

            mockSession.Setup(s => s.TryGetValue("UserId", out userIdBytes)).Returns(userId.HasValue);
            mockSession.Setup(s => s.TryGetValue("UserRole", out roleBytes)).Returns(role != null);

            var mockHttpContext = new Mock<HttpContext>();
            mockHttpContext.Setup(c => c.Session).Returns(mockSession.Object);

            controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };
        }

        [Fact]
        public async Task CreateEvent_AsParticipant_ReturnsForbid()
        {
            // Arrange
            var context = GetInMemoryDbContext();

            // 1. Create a mock BlobService
            var mockConfig = new Mock<IConfiguration>();
            var mockBlobService = new Mock<BlobService>(mockConfig.Object);

            // 2. Pass the mock into the controller
            var controller = new EventsController(context, mockBlobService.Object);

            // Simulate a Participant trying to create an event
            SetupSession(controller, 1, "Participant");

            // 3. Use CreateEventDto instead of Event
            var newEventDto = new CreateEventDto { Name = "Test Event" };

            // Act
            var result = await controller.CreateEvent(newEventDto);

            // Assert
            Assert.IsType<ForbidResult>(result);
        }

        [Fact]
        public async Task CreateEvent_AsOrganiser_ReturnsOk()
        {
            // Arrange
            var context = GetInMemoryDbContext();

            // 1. Create a mock BlobService
            var mockConfig = new Mock<IConfiguration>();
            var mockBlobService = new Mock<BlobService>(mockConfig.Object);

            // 2. Pass the mock into the controller
            var controller = new EventsController(context, mockBlobService.Object);

            // Simulate an Organiser trying to create an event
            SetupSession(controller, 1, "Organiser");

            // 3. Use CreateEventDto instead of Event
            var newEventDto = new CreateEventDto { Name = "Test Event", EventType = "run", Date = DateTime.Now };

            // Act
            var result = await controller.CreateEvent(newEventDto);

            // Assert
            Assert.IsType<OkObjectResult>(result);
            // Note: If you aren't adding a User to the DB before creating the event, this count might be 0.
            // You may need to mock adding a user to the context first.
            // Assert.Equal(1, await context.Users.CountAsync()); 
        }
    }
}