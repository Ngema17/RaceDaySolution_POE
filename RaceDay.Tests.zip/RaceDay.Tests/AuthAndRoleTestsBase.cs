﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Controllers;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;

namespace RaceDay.Tests
{
    public class AuthAndRoleTestsBase
    {

        [Fact]
        public async Task LoginInvalidPasswordReturnsUnauthorized()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            context.Users.Add(new User { Email = "test@test.com", PasswordHash = BCrypt.Net.BCrypt.HashPassword("CorrectPassword"), Role = "Participant" });
            await context.SaveChangesAsync();

            var controller = new AuthController(context);
            var request = new LoginDto { Email = "test@test.com", Password = "WrongPassword" };

            // Act
            var result = await controller.Login(request);

            // Assert
            Assert.IsType<UnauthorizedObjectResult>(result);
        }

        [Fact]
        public async Task RegisterValidUserReturnsOk()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var controller = new AuthController(context);
            var request = new RegisterDto { FirstName = "Test", LastName = "User", Email = "test@test.com", Password = "Password123!", Role = "Participant" };

            // Act
            var result = await controller.Register(request);

            // Assert
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(1, await context.Users.CountAsync<RaceDay.API.Models.User>());
        }
        // Helper method to create an in-memory database for testing
        protected AppDbContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            var context = new AppDbContext(options);
            context.Database.EnsureCreated();
            return context;
        }
    }
}